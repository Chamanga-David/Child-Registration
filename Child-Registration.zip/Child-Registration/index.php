<!-- menu starts here -->

<?php include('partials/menu.php'); ?>

<!-- menu ends here -->