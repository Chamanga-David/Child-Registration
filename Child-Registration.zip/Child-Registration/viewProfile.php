  <!-- Calling the menu here -->
  <?php include('partials/menu.php'); ?>

    <!-- Child Profile Section Starts Here -->
    <section class="child-search">
        <div class="container">
            <h2 class="text-white">CHILD PROFILE</h2><br>

            <?php

               //1. get the ID of select child
                   $id = $_GET['id'];

                //2. Create sql to select a selected child
                  $sql = "SELECT * FROM tbl_child WHERE id=$id";

                //3. Execute the query
                $res=mysqli_query($conn,$sql);

                //4. count rows
                $count =mysqli_num_rows($res);

                //5.check whether child is available or not
                if($count>0)
                {
                    //Child is available
                    while($row=mysqli_fetch_assoc($res))
                    {
                       //Get the child details
                         $id =$row['id'];  
                         $first_name =$row['first_name'];  
                         $last_name =$row['last_name'];  
                         $age =$row['age'];  
                         $gender =$row['gender'];  
                         $immunization =$row['immunization'];  
                      ?>
                         <!-- Table details comes here -->
                        <fieldset>
                            <legend>Child Profile</legend><br>
                            <table class="tbl-30">
                                <tr>
                                    
                                    <td><b>FIRST NAME :</b></td>
                                    <td><?php echo $first_name; ?></td>
                                </tr>

                                <tr>
                                    <td><b>LAST NAME :</b></td>
                                    <td><?php echo $last_name; ?></td>
                                </tr>

                                <tr>
                                    <td><b>AGE :</b></td>
                                    <td><?php echo $age; ?></td>
                                </tr>

                                <tr>
                                    <td><b>GENDER :</b></td>
                                    <td><?php echo $gender; ?></td>
                                </tr>

                                <tr>
                                    <td><b>IMMUNIZATIONS :</b></td>
                                    <td><?php echo $immunization; ?></td>
                                </tr>
                            </table>
                </fieldset>



                      <?php
                    }
                }
                else{
                    //child not available
                     echo "<div class='error'>Child Is Not Available...</div>";
                }


                ?>

                
            </form>
        </div>
    </section><br>
      <!-- Calling the footer here -->
   <?php include('partials/footer.php'); ?>
</body>
</html>