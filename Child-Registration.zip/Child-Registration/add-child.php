<?php include('partials/menu.php'); ?>
<div class="main-content">
    <div class="wrapper">
        <h1>Add Child</h1>
        <br><br>
          <form action="" method="POST">
            <table class="tbl-30">
                <tr>
                    <td>First Name: </td>
                    <td><input type="text" name="first_name" placeholder="Enter First name" required></td>
                </tr>
                <tr>
                    <td>Last Name: </td>
                    <td><input type="text" name="last_name" placeholder="Enter last name" required></td>
                </tr>
                <tr>
                    <td>Age: </td>
                    <td>
                        <input type="number" name="age" required>
                    </td>
                </tr>
                <tr>
                    <td>Gender:</td>
                    <td>
                        <input type="radio" name="gender" value="Male"> Male
                        <input type="radio" name="gender" value="Female"> Female
                    </td>
                </tr>
                <tr>
                    <td>Immunization:</td>
                    <td>
                        <select name="immunization" required>
                            <option value="#">Select Immunization</option>
                            <option value="BCG">BCG</option>
                            <option value="MMR">MMR</option>
                            <option value="RV">RV</option>
                            <option value="DTaP">DTap</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="submit" name="submit" value="Register Child" class="btn-secondary">
                    </td>
                </tr>
            </table>
        </form>

        <?php 
        //check if button is clicked or not
        if(isset($_POST['submit']))
        {
            //Add child in the database
           // echo "clicked";
           //1. Get the data from the form 
           $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
           $last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
           $age = mysqli_real_escape_string($conn, $_POST['age']);
           $immunization = mysqli_real_escape_string($conn, $_POST['immunization']);

           //Check whether radio button for gender is checked
           if(isset($_POST['gender']))
                {
                        $gender =$_POST['gender'];
                }
           else{
                $gender ="No"; //setting default value
           }

           //3. Insert into database
           //Create Sql query to save or add child
           
           $sql = "INSERT INTO tbl_child SET
           first_name = '$first_name',
           last_name = '$last_name',
           age = $age,
           gender = '$gender',
           immunization = '$immunization'
           ";

           //Excute the query
           $res=mysqli_query($conn,$sql);
           //Check whether data is inserted or not

           //4. Redirect to child page
           if($res ==true)
           {
            //data inserted
            $_SESSION['add']="<div class='success'><b>Child Registered Successfully.</b></div>";
            header("location:".SITEURL.'manage-child.php');
           }
           else{
            //failed to insert data
            $_SESSION['add']="<div class='error'> Failed to Register Child..</div>";
            header("location:".SITEURL.'manage-child.php');
                 }
            }
        ?>
    </div>
</div>
   <!-- Calling the footer here -->
   <?php include('partials/footer.php'); ?>