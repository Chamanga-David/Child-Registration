<?php include('partials/menu.php'); ?>

<div class="main-content">
<div class="wrapper">
   <h1>Manage Children</h1>
   <br/><br/>

   <?php 
        if(isset($_SESSION['add']))
        {
            echo $_SESSION['add'];
            unset($_SESSION['add']);
     }
    if(isset($_SESSION['unauthorized']))
           {
               echo $_SESSION['unauthorized'];
               unset($_SESSION['unauthorized']);
                }
            
    if(isset($_SESSION['update']))
        {
            echo $_SESSION['update'];
            unset($_SESSION['update']);
        }        
      ?>
   <br/><br/>
                <!-- Button to add admin -->
                <!-- <a href="<?php echo SITEURL; ?>admin/add-service.php" class="btn-primary">Add Child</a> -->
                <br/><br/>
                <table class="tbl-full">
                    <tr>
                        <th>Sno.</th>
                        <th>Firstname</th>
                        <th>Lastname</th>
                        <th>Age</th>
                        <th>Gender</th>
                        <th>Immunization</th>
                        <th>Actions</th>
                    </tr>
                    <?php 

                          //Geting pagination
                            $num_per_page=04;
                            if(isset($_GET["page"]))
                                {
                                    $page = $_GET["page"];
                                    }
                                else{
                                    $page=1;
                                }
                                    $start_from=($page-1)*04;
                                    $sql ="SELECT * from tbl_child ORDER BY id DESC LIMIT  $start_from, $num_per_page"; //Display latest order at first Order by Desc
                                    //Execute Query
                                    $res=mysqli_query($conn, $sql);
                                    //end pagination here


                        //create sql query to get all the service
                        //$sql = "SELECT * FROM tbl_service ORDER BY id DESC";

                        //Execute the query
                        //$res =mysqli_query($conn, $sql);

                        //Count the row to check whether we have service data or not
                        $count =mysqli_num_rows($res);

                        //create serial number and set default as 1
                        $sn=1;

                        if($count>0)
                        {
                            //We have services data
                            //Get the services from database and display
                            while($row=mysqli_fetch_assoc($res))
                            {
                                //Get the values from individual columns
                                $id = $row['id'];
                                $first_name = $row['first_name'];
                                $last_name =$row['last_name'];
                                $age=$row['age'];
                                $gender = $row['gender'];
                                $immunization = $row['immunization'];
                                ?>

                                <tr>
                                        <td><?php echo $sn++; ?>. </td>
                                        <td><?php echo $first_name; ?></td>
                                        <td><?php echo $last_name; ?></td>
                                        <td><?php echo $age; ?></td>
                                        <td><?php echo $gender; ?></td>
                                        <td><?php echo $immunization; ?></td>
                                        <td>
                                    <a href="<?php echo SITEURL; ?>viewProfile.php?id=<?php echo $id; ?>" class="btn-secondary">View profile</a>
                             </td>
                        </tr>
                            <?php
                            }
                        }
                        else{
                            //Services not added in database
                            echo "<tr> <td colspan='7' class='error'> No Child Available... </td></tr>";
                        }
                    ?>

                </table>

                <?php 
                //Used for Pagination fro tables....
                $sql2="SELECT * FROM tbl_child";
                $re_result =mysqli_query($conn, $sql2);
                $total_record=mysqli_num_rows($re_result);
                //echo $total_record
                $total_pages=ceil($total_record/$num_per_page);
                //echo $total_pages;

                for($i=1;$i<=$total_pages;$i++)
                {
                    echo "<a href='manage-child.php?page=".$i."'>".$i."</a>";
                }
        ?>
    </div>
</div>

<!-- Calling the footer here -->
<?php include('partials/footer.php'); ?>