
        <!-- Menu footer start here -->
        <div class="footer">
               <div class="wrapper">
                <p class="text-center">2023 All rights reserved, Child Registration Developed by - <a href="#">Chamanga David</a></p>
               </div>
            </div>
            <!-- Menu footer end here -->
        </body>
    </html>